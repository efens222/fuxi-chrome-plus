// Empty background script for future use
