//const BACKEND_URL = "http://127.0.0.1:5000";
const BACKEND_URL = "http://m3u8home.top:5000";
const your_secure_plugin_token="c261bfa02c8d77e4c25d3ca3eb8c1484e972064e372e90209f62cb47d73214eb";
document.addEventListener("DOMContentLoaded", function() {
const userId = localStorage.getItem("user_id");
const password = localStorage.getItem("password");
if (userId) {
document.getElementById("loginSection").style.display = "none";
document.getElementById("registerSection").style.display = "none";
document.getElementById("consoleSection").style.display = "block";
document.getElementById("username").textContent = userId;
fetchUserInfo(userId);
} else {
document.getElementById("loginSection").style.display = "block";
}
document.getElementById("loginForm").addEventListener("submit", function(event) {
event.preventDefault();
const userId = document.getElementById("user_id").value;
const password = document.getElementById("password").value;
fetch(`${BACKEND_URL}/login`,{
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify({ user_id: userId, password: password })
})
.then(response => response.json())
.then(data => {
if (data.success) {
localStorage.setItem("user_id", userId);
localStorage.setItem("password", password);
window.location.reload();
} else {
document.getElementById("errorMessage").style.display = "block";
}
});
});
document.getElementById("registerForm").addEventListener("submit", regForm);
async function regForm(event) {
event.preventDefault();
const newUserId = document.getElementById("new_user_id").value;
const newPassword = document.getElementById("new_password").value;
const newExchange = document.querySelector("label[for='new_exchange_text']").textContent;
const newSymbol = document.getElementById("new_symbol").value;
const mode_selected = document.querySelector('input[name="trade_mode"]:checked');
const type_selected = document.querySelector('input[name="trade_type"]:checked');
const apiKey = document.getElementById("apiKey").value;
const secret = document.getElementById("secret").value;
const inviteCodeBy = document.getElementById("inviteCodeBy").value;	
fetch(`${BACKEND_URL}/register`,{
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify({
user_id: newUserId,
password: newPassword,
exchange: newExchange,
trade_mode:mode_selected.value,
apiKey:apiKey,
secret:secret,
category:type_selected.value,
symbol: newSymbol,
inviteCodeBy:inviteCodeBy
})
})
.then(response => response.json())
.then(data => {
alert(data.message);
if (data.success) {
localStorage.setItem("user_id", newUserId);
localStorage.setItem("password", newPassword);
window.location.reload();
document.getElementById("registerSection").style.display = "none";
document.getElementById("loginSection").style.display = "block";
document.getElementById("consoleSection").style.display = "none";
document.getElementById("recommend-details").style.display = "none";
document.getElementById("main-actions").style.display = "none";
}
});
}
document.getElementById("setupForm").addEventListener("submit", setupForm);
async function setupForm(event) {
event.preventDefault();
const userId = localStorage.getItem("user_id");
const newSymbol = document.getElementById("set_symbol").value;
const mode_selected = document.querySelector('input[name="set_trade_mode"]:checked');
const type_selected = document.querySelector('input[name="set_trade_type"]:checked');
const apiKey = document.getElementById("set_apiKey").value;
const secret = document.getElementById("set_secret").value;
const lot = document.getElementById("set_Lot").value;
const sl = document.getElementById("set_Sl").value;
const tp = document.getElementById("set_Tp").value;
fetch(`${BACKEND_URL}/setup`,{
method: "POST",
headers: { "Content-Type": "application/json" ,"X-API-Token": your_secure_plugin_token},
body: JSON.stringify({
user_id: userId,
trade_mode:mode_selected.value,
apiKey:apiKey,
secret:secret,
category:type_selected.value,
symbol: newSymbol,
lot:lot,
sl:sl,
tp:tp
})
})
.then(response => response.json())
.then(data => {
alert(data.message);
if (data.success) {
window.location.reload();
document.getElementById("registerSection").style.display = "none";
document.getElementById("loginSection").style.display = "none";
document.getElementById("consoleSection").style.display = "block";
document.getElementById("recommend-details").style.display = "none";
document.getElementById("main-actions").style.display = "none";
}
});
}
});
document.getElementById("manualOpenButtonBuy").addEventListener("click",openBuy);
async   function openBuy() {
const lot = document.getElementById("manualLot").value;
const sl = document.getElementById("manualSl").value;
const tp = document.getElementById("manualTp").value;
const userId = localStorage.getItem("user_id");
const pwd = localStorage.getItem("password");
const symbol = document.getElementById("manualsymbol").value;
const category = document.querySelector('input[name="man_trade_type"]:checked').value;
if (!lot) {
console.log("手数为空，请输入有效值");
} else {
console.log("手数是：" + lot);
}
fetch(`${BACKEND_URL}/manual_open_buy`,{
method: "POST",
headers: { "Content-Type": "application/json" ,
"X-API-Token": your_secure_plugin_token},
body: JSON.stringify({ user_id: userId,pwd:pwd,category,symbol, lot, sl, tp })
})
.then(response => response.json())
.then(data => {
alert(data.message);
});
}
document.getElementById("manualOpenButtonSell").addEventListener("click",openSell);
async   function openSell() {
const lot = document.getElementById("manualLot").value;
const sl = document.getElementById("manualSl").value;
const tp = document.getElementById("manualTp").value;
const userId = localStorage.getItem("user_id");
const pwd = localStorage.getItem("password");
const symbol = document.getElementById("manualsymbol").value;
const category = document.querySelector('input[name="man_trade_type"]:checked').value;
if (!lot) {
console.log("手数为空，请输入有效值");
} else {
console.log("手数是：" + lot);
}
fetch(`${BACKEND_URL}/manual_open_sell`,{
method: "POST",
headers: { "Content-Type": "application/json" ,"X-API-Token": your_secure_plugin_token},
body: JSON.stringify({ user_id: userId,pwd:pwd,category,symbol, lot, sl, tp })
})
.then(response => response.json())
.then(data => {
alert(data.message);
});
}
document.getElementById("manualCloseButton").addEventListener("click",closePos);
async   function closePos() {
const lot = document.getElementById("closeQty").value;
const userId = localStorage.getItem("user_id");
const pwd = localStorage.getItem("password");
const symbol = document.getElementById("manualsymbol").value;
const category ="linear"; 
if (!lot) {
console.log("手数为空，请输入有效值");lots=0;
alert(lots);
} else {
console.log("手数是：" + lot);
lots=lot;
}
fetch(`${BACKEND_URL}/manual_close_pos`,{
method: "POST",
headers: { "Content-Type": "application/json" ,"X-API-Token": your_secure_plugin_token},
body: JSON.stringify({ user_id: userId,pwd:pwd,category,symbol, lots:lots })
})
.then(response => response.json())
.then(data => {
alert(data.message);
});
}
function fetchUserInfo(userId) {
fetch(`${BACKEND_URL}/user_info?user_id=${userId}`)
.then(response => response.json())
.then(data => {
document.getElementById("points").textContent = data.points;
document.getElementById("inviteSum").textContent = data.inviteSum;
if (data.isDemo === "demo" || data.isDemo === "real") {
  const radios_demo = document.getElementsByName("set_trade_mode");
  for (let i = 0; i < radios_demo.length; i++) {
    if (radios_demo[i].value === data.isDemo) {
      radios_demo[i].checked = true;
      break;
    }
  }
}
if (data.category === "linear" || data.category === "spot") {
  const radios = document.getElementsByName("set_trade_type");
  for (let i = 0; i < radios.length; i++) {
    if (radios[i].value === data.category) {
      radios[i].checked = true;
      break;
    }
  }
}

document.getElementById("set_symbol").value = data.symbol;
document.getElementById("set_Lot").value = data.lots;
document.getElementById("set_Sl").value = data.sl;
document.getElementById("set_Tp").value = data.tp;
});
}
async function fetchLogs() {
const user_id = localStorage.getItem("user_id");
console.log("user_id：" + user_id);
const res = await fetch(`${BACKEND_URL}/logs?user_id=${user_id}`);
const data = await res.json();
document.getElementById("logBox").value = data.logs;
}
async function updateStatus() {
try {
	const user_id = localStorage.getItem("user_id");
const res = await fetch(`${BACKEND_URL}/status?user_id=${user_id}`);
// if (res.ok) {
    // const data = await res.json();
    // console.log("状态数据：", data); // 正确查看内容
// } else {
    // console.error("请求失败：", res.status);
// }
const data = await res.json();
document.getElementById("statusText").textContent = data.running ? "运行中 ✅" : "已停止 ⏹️";
} catch (err) {
console.error("获取状态失败", err);
document.getElementById("statusText").textContent = "无法连接❌";
}
}
document.getElementById("startStrategyButton").addEventListener("click", startStrategy);
async function startStrategy() {
console.log("点击了启动按钮！");
try {
const user_id = localStorage.getItem("user_id");
const pwd = localStorage.getItem("password");
console.log("点击了启动按钮！",pwd);
const res = await fetch(`${BACKEND_URL}/start`, {
method: "POST",
headers: { "Content-Type": "application/json" ,"X-API-Token": your_secure_plugin_token},
body: JSON.stringify({user_id ,pwd})
});
const data = await res.json();
// console.log("策略启动返回:", data);
// alert(data.message);
updateStatus();
} catch (err) {
console.error("启动失败：", err);
document.getElementById("statusText").textContent = "启动失败";
}
}
document.getElementById("stopStrategyButton").addEventListener("click", stopStrategy);
async function stopStrategy() {
const user_id = localStorage.getItem("user_id");
const pwd = localStorage.getItem("password");
const res = await fetch(`${BACKEND_URL}/stop`, {
method: "POST",
headers: { "Content-Type": "application/json" ,"X-API-Token": your_secure_plugin_token},
body: JSON.stringify({user_id ,pwd})
});
// const data = await res.json();
// alert(data.message);
updateStatus();
}
let isOn = false;
document.getElementById("setupStrategyButton").addEventListener("click", setupStrategy);
async function setupStrategy() {
isOn = !isOn;
this.textContent = isOn ? '关闭设置策略' : '设置策略';
console.log("当前状态是：" + (isOn ? "ON" : "OFF"));
if (isOn){
document.getElementById("loginSection").style.display = "none";
document.getElementById("registerSection").style.display = "none";
document.getElementById("consoleSection").style.display = "block";
document.getElementById("setupSection").style.display = "block";
document.getElementById("recommend-details").style.display = "none";
document.getElementById("main-actions").style.display = "none";
}
else{
document.getElementById("setupSection").style.display = "none";
}
}
window.onload = function() {
fetchLogs();   
updateStatus();  
setInterval(() => {
fetchLogs();
updateStatus(); 
}, 5000);
}
document.addEventListener("DOMContentLoaded", function () {
const trigger = document.getElementById("menu-trigger");
const dropdown = document.getElementById("menu-dropdown");
trigger.addEventListener("mouseenter", () => {
dropdown.style.display = "block";
});
trigger.addEventListener("mouseleave", () => {
setTimeout(() => {
if (!dropdown.matches(":hover")) {
dropdown.style.display = "none";
}
}, 200);
});
dropdown.addEventListener("mouseleave", () => {
dropdown.style.display = "none";
});
dropdown.addEventListener("mouseenter", () => {
dropdown.style.display = "block";
});
});
document.addEventListener("DOMContentLoaded", logoutLink);
async function logoutLink() {
const logoutBtn = document.getElementById("logout-link");
logoutBtn.addEventListener("click", function () {
fetch(`${BACKEND_URL}/logout`,{
method: "POST",  
credentials: "include"
})
.then(response => {
document.getElementById("loginSection").style.display = "block";
document.getElementById("registerSection").style.display = "none";
document.getElementById("consoleSection").style.display = "none";
document.getElementById("recommend-details").style.display = "none";
document.getElementById("main-actions").style.display = "none";
})
.catch(error => {
console.error("退出登录错误:", error);
alert("网络错误，退出失败");
});
});
}
document.getElementById("register-link").addEventListener("click", registerLink);
async function registerLink() {
document.getElementById("loginSection").style.display = "none";
document.getElementById("registerSection").style.display = "block";
document.getElementById("consoleSection").style.display = "none";
document.getElementById("recommend-details").style.display = "none";
document.getElementById("main-actions").style.display = "none";
}
document.getElementById("recommend-link").addEventListener("click", recommendLink);
async function recommendLink() {
document.getElementById("loginSection").style.display = "none";
document.getElementById("registerSection").style.display = "none";
document.getElementById("consoleSection").style.display = "none";
const details = document.getElementById("recommend-details");
const main = document.getElementById("main-actions");
main.style.display = "none";
details.style.display = "block";
}
document.addEventListener("DOMContentLoaded", () => {
const showBtn = document.getElementById("show-recommend-btn");
const backBtn = document.getElementById("backBtn");
const details = document.getElementById("recommend-details");
const main = document.getElementById("main-actions");
const refInput = document.getElementById("referrer");
const copyBtnCode = document.getElementById("copyCodeBtn");
const codeInput = document.getElementById("inviteCode");
const copyBtn = document.getElementById("copyLinkBtn");
const linkInput = document.getElementById("inviteLink");
const statusMsg = document.getElementById("copyStatus");
const user_id = localStorage.getItem("user_id");
console.log(user_id);
fetch(`${BACKEND_URL}/invite`,{
method: "POST",
headers: { "Content-Type": "application/json" ,"X-API-Token": your_secure_plugin_token},
body: JSON.stringify({ user_id: user_id})
})
.then(res => res.json())
.then(data => {
refInput.value = data.referrer;
codeInput.value = data.inviteCode;
linkInput.value = data.inviteLink;
});
showBtn.addEventListener("click", () => {
main.style.display = "none";
details.style.display = "block";
});
backBtn.addEventListener("click", () => {
details.style.display = "none";
main.style.display = "block";
document.getElementById("consoleSection").style.display = "block";
});
copyBtnCode.addEventListener("click", () => {
codeInput.select();
//codeInput.setSelectionRange(0, 9999);
navigator.clipboard.writeText(codeInput.value).then(() => {
statusMsg.style.display = "block";
setTimeout(() => {
statusMsg.style.display = "none";
}, 2000);
}).catch(() => {
alert("复制失败，请手动复制");
});
});
copyBtn.addEventListener("click", () => {
linkInput.select();
//linkInput.setSelectionRange(0, 9999);
navigator.clipboard.writeText(linkInput.value).then(() => {
statusMsg.style.display = "block";
setTimeout(() => {
statusMsg.style.display = "none";
}, 2000);
}).catch(() => {
alert("复制失败，请手动复制");
});
});
});